// SPDX-FileCopyrightText: 2026 aeterna-rongroi contributors
// SPDX-License-Identifier: GPL-3.0-or-later
// Part of aeterna-rongroi, a cheat-detection tool. Using it to evade detection is out of scope — see AGENTS.md.

// L4: the UI renders the same report the Rust pipeline produces (the insta snapshots), through mocked IPC.

import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { clearMocks, mockIPC } from "@tauri-apps/api/mocks";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { App } from "./App";
import i18n, { initI18n } from "./i18n";
import type { ReportHeader, ReportView, RuleText, UnmeasuredReason } from "./types";
import { COPIED_FOR_MS } from "./views/CodeLink";

// Vitest runs with apps/desktop as the working directory.
const SNAPSHOTS = resolve(process.cwd(), "../../crates/bope-collectors/tests/snapshots");

/** Reads an insta snapshot, strips its front matter (`---\n…\n---\n`) and parses the JSON body. */
function snapshot(name: string): ReportView {
  const raw = readFileSync(resolve(SNAPSHOTS, `report_snapshot__${name}.snap`), "utf8");
  const body = raw.replace(/\r\n/g, "\n").split("\n---\n").slice(1).join("\n---\n");
  return JSON.parse(body) as ReportView;
}

const RULE_ID = "7c1f3a52-9d4e-4b8a-a6f2-3e5d9b0c41e7";
const ENGLISH_RETENTION =
  "Current setting only. It says nothing about how the PC was configured in the past.";
const THAI_RETENTION = "เป็นค่าที่ตั้งไว้ตอนนี้เท่านั้น บอกไม่ได้ว่าในอดีตเครื่องนี้เคยตั้งค่าไว้อย่างไร";
// Both are mandatory in every rule and CI rejects a rule that leaves either empty, so the mock
// carries them the way the real bundle does (ADR 0027).
const ENGLISH_DESCRIPTION = "Windows reports that UEFI Secure Boot is off.";
const THAI_DESCRIPTION = "Windows รายงานว่า UEFI Secure Boot ปิดอยู่";
const ENGLISH_FALSEPOSITIVE = "PCs that boot in legacy BIOS or CSM mode";
const THAI_FALSEPOSITIVE = "เครื่องที่บูตแบบ legacy BIOS หรือ CSM";
const selfView = snapshot("secure_boot_off_self_view");
const ssView = snapshot("secure_boot_off_ss_view");

// The evidence entry these tests build their overrides from: the Secure Boot rule, found by id
// rather than taken as `evidence[0]`. Every assertion below is about that rule's own text, and the
// order of the evidence list is the order of the rules bundle — which changes whenever a rule is
// added, as `rules/evtx/` did.
function subject(view: ReportView) {
  const found = view.evidence.find((item) => item.rule_id === RULE_ID);
  if (!found) {
    throw new Error(`the snapshot has no evidence for ${RULE_ID}`);
  }
  return found;
}
let calls: string[] = [];
let viewOverride: ReportView | null = null;
/** Rule texts added to the mocked `rule_texts` answer, for tests that need a timeline selector's. */
let extraTexts: Record<string, RuleText> = {};
let headerOverride: ReportHeader | null = null;
/** What `app_info` answers; `elevated` is what the start screen reads. */
let infoElevated: boolean | null = true;
/** What `scan_status` answers after `start_scan`. */
let scanState: "running" | "done" | "cancelled" = "done";
let exportedWith: Record<string, unknown> | null = null;
let startedTier: unknown = null;
let linksOverride: { repository: string; code: string; commit: string | null } | null = null;
// Carried fix (b): a `code_links` call that never resolves, so `links` stays `null` — the same shape
// the UI sees while the call is still in flight or after it failed.
let linksNeverResolve = false;
/** An IPC call Rust refused, for the pages that must say so rather than stay blank. */
let headerFails = false;
let linksFail = false;
let clipboardWrites: string[] = [];
const REPOSITORY = "https://github.com/aeterna/aeterna-rongroi";
const COMMIT = "2c673c54aeb084cd3773057efbb9ed3b98fd2dbc";
// Carried fix (d): the real descriptor before any test stubs it, so it can be restored afterwards
// instead of leaking a fake `navigator.clipboard` into the next test file.
const originalClipboardDescriptor = Object.getOwnPropertyDescriptor(navigator, "clipboard");

beforeAll(async () => {
  await initI18n("en");
});

beforeEach(async () => {
  calls = [];
  viewOverride = null;
  extraTexts = {};
  headerOverride = null;
  linksOverride = null;
  infoElevated = true;
  scanState = "done";
  exportedWith = null;
  startedTier = null;
  linksNeverResolve = false;
  headerFails = false;
  linksFail = false;
  clipboardWrites = [];
  await i18n.changeLanguage("en");
  mockIPC(mockIPCAnswer);
});

/** The default IPC answers; a test that needs to see an argument wraps it. */
function mockIPCAnswer(cmd: string, args: unknown): unknown {
  {
    calls.push(cmd);
    const payload = (args ?? {}) as Record<string, unknown>;
    switch (cmd) {
      case "report_header":
        if (headerFails) {
          throw new Error("refused");
        }
        return headerOverride ?? selfView.header;
      case "report_view":
        return viewOverride ?? (payload.mode === "ss" ? ssView : selfView);
      case "rule_texts":
        return {
          ...extraTexts,
          [RULE_ID]: {
            title: payload.lang === "th" ? "Secure Boot ถูกปิดอยู่" : "Secure Boot is turned off",
            description: payload.lang === "th" ? THAI_DESCRIPTION : ENGLISH_DESCRIPTION,
            falsepositives: [payload.lang === "th" ? THAI_FALSEPOSITIVE : ENGLISH_FALSEPOSITIVE],
            retention: payload.lang === "th" ? THAI_RETENTION : ENGLISH_RETENTION,
            status: "test",
            files: {
              rule: "rules/posture/boot/secure-boot-disabled/rule.yaml",
              fixtures: "rules/posture/boot/secure-boot-disabled/tests",
              collector: "crates/bope-collectors/src/posture.rs",
              references: [],
            },
          },
        };
      case "age_texts":
        return {
          prefetch: {
            retention:
              payload.lang === "th"
                ? "Windows ลบไฟล์ Prefetch เอง"
                : "Windows removes Prefetch files itself.",
            documented: false,
            references: ["docs/adr/0030-the-words-for-what-was-not-measured.md"],
          },
        };
      case "code_links":
        if (linksNeverResolve) {
          return new Promise(() => {});
        }
        if (linksFail) {
          throw new Error("refused");
        }
        return linksOverride ?? { repository: REPOSITORY, code: REPOSITORY, commit: null };
      case "app_info": {
        if (headerFails) {
          throw new Error("refused");
        }
        const header = headerOverride ?? selfView.header;
        return {
          version: header.provenance.version,
          official: header.provenance.official,
          exe_sha256: header.provenance.exe_sha256,
          rules: header.rules_bundle,
          elevated: infoElevated,
          platform: header.platform,
          os_build: header.os_build,
          collectors: [
            { id: "roblox", tier: "standard", category: "roblox" },
            { id: "posture", tier: "standard", category: "firmware_boot" },
            { id: "browser_ext", tier: "full", category: "browser_scripts" },
          ],
        };
      }
      case "rule_meta":
        return {};
      case "start_scan":
        startedTier = payload.tier;
        return true;
      case "cancel_scan":
        scanState = "cancelled";
        return null;
      case "scan_status":
        return {
          state: scanState,
          steps: [
            {
              done: 1,
              total: 3,
              collector: "roblox",
              state: "measured",
              reason: null,
              observations: 4,
              gaps: 0,
              found_rules: [RULE_ID],
              elapsed_ms: 120,
            },
          ],
          total: 3,
          started_at: "2026-10-15T12:00:00Z",
          message: null,
          tier: "standard",
        };
      case "default_export_dir":
        return "C:\\Users\\x\\Documents\\B.O.P.E Scanner";
      case "pick_export_dir":
        return null;
      case "export_report":
        exportedWith = payload;
        return [
          { path: "C:\\Users\\x\\Documents\\B.O.P.E Scanner\\r.html", sha256: "ab".repeat(32) },
        ];
      case "code_link_qr":
        return `<?xml version="1.0" standalone="yes"?><svg xmlns="http://www.w3.org/2000/svg"></svg>`;
      default:
        throw new Error(`unexpected command ${cmd}`);
    }
  }
}

afterEach(() => {
  cleanup();
  clearMocks();
  if (originalClipboardDescriptor) {
    Object.defineProperty(navigator, "clipboard", originalClipboardDescriptor);
  } else {
    // jsdom had no `navigator.clipboard` of its own before any test stubbed it.
    (navigator as { clipboard?: unknown }).clipboard = undefined;
  }
});

/** Goes through the start screen and the scan to the report, as a person does (ADR 0115). */
async function openReport(mode: "self" | "ss", tier: "standard" | "full" = "standard") {
  fireEvent.click(
    await screen.findByLabelText(
      mode === "ss" ? /Screenshare \(SS mode\)/ : /Only me \(self check\)/,
    ),
  );
  if (tier === "full") {
    fireEvent.click(screen.getByLabelText(/^Advanced/));
  }
  fireEvent.click(screen.getByLabelText("I have read what will be examined and I agree"));
  fireEvent.click(screen.getByText("Start the check"));
}

/** Opens a closed row by clicking its title. */
function openRow(title: string) {
  fireEvent.click(screen.getByText(title));
}

function stubClipboard(result: "ok" | "refused") {
  Object.defineProperty(navigator, "clipboard", {
    configurable: true,
    value: {
      writeText: (text: string) => {
        if (result === "refused") {
          return Promise.reject(new Error("refused"));
        }
        clipboardWrites.push(text);
        return Promise.resolve();
      },
    },
  });
}

describe("App", () => {
  it("snapshots are the Rust pipeline output", () => {
    expect(selfView.mode).toBe("self");
    expect(ssView.mode).toBe("ss");
    expect(subject(selfView).rule_id).toBe(RULE_ID);
  });

  it("announces an unofficial build on the start screen", async () => {
    render(<App />);
    expect(await screen.findByRole("alert")).toHaveProperty(
      "textContent",
      expect.stringContaining("UNOFFICIAL BUILD"),
    );
  });

  // B.O.P.E, ADR 0123: the Roblox tool correlation has its own panel, with each tool's status, the
  // independent sources behind it, its traces on demand, and which sources could be read.
  it("shows the Roblox tools panel with status, sources and traces", async () => {
    const row = (fields: Record<string, unknown>) => ({ collector: "roblox_trace", fields });
    viewOverride = {
      ...snapshot("trace_ages_elevated_ss_view"),
      roblox_tools: {
        tools: [
          row({
            scope: "tool",
            tool_id: "fluxus",
            display: "Fluxus",
            status: "corroborated",
            families: "amcache, userassist",
            families_count: 2,
            classes: "execution, inventory",
            missing_now: true,
            first_seen: "2026-10-14T20:01:00Z",
            last_seen: "2026-10-14T22:40:00Z",
          }),
          row({
            scope: "tool",
            tool_id: "bloxstrap",
            display: "Bloxstrap",
            status: "info",
            common_legitimate: true,
            families: "file_listing",
            families_count: 1,
            classes: "current_file",
          }),
        ],
        hits: [
          row({
            scope: "hit",
            tool_id: "fluxus",
            source: "userassist",
            evidence_class: "execution",
            path: "C:\\Users\\<user>\\Downloads\\Fluxus\\Fluxus.exe",
            time: "2026-10-14T20:02:00Z",
            exists: false,
          }),
        ],
        sources: [
          row({ scope: "source", source: "prefetch", state: "not_measured", reason: "not_admin" }),
          row({ scope: "source", source: "amcache", state: "measured" }),
          row({ scope: "source", source: "srum", state: "measured" }),
          row({ scope: "source", source: "mft", state: "not_applicable", reason: "not_consented" }),
          row({ scope: "source", source: "wmi_subscription", state: "measured" }),
        ],
      },
    };
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("Roblox tools")).toBeTruthy();
    expect(screen.getByText("CORROBORATED")).toBeTruthy();
    expect(screen.getByText("Fluxus")).toBeTruthy();
    expect(screen.getByText("Bloxstrap")).toBeTruthy();
    expect(screen.getByText("commonly used legitimately ·")).toBeTruthy();
    expect(screen.getByText("execution recorded; inventory (not proof of execution)")).toBeTruthy();
    fireEvent.click(screen.getByText("Show the 1 traces"));
    expect(screen.getByText(/not at this path today/)).toBeTruthy();
    expect(screen.getByText("Sources the correlation could use")).toBeTruthy();
    expect(screen.getByText("(not_admin)")).toBeTruthy();
    // B.O.P.E 0.10.0: the new sources are named, and one a standard scan does not read says so.
    expect(screen.getAllByText(/SRUM/).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/Master File Table/).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/WMI/).length).toBeGreaterThan(0);
    expect(screen.getByText("(not_consented)")).toBeTruthy();
  });

  // ADR 0051: the SS view shows its timeline, with what it never says above it, and the scan's own
  // time as an anchor.
  // ADR 0061: the SS view shows how far back each source reaches, beside the anchors; a source not
  // read without administrator rights is "not known", never "empty"; the statement is shown with
  // every record's line and its ordinary causes in full.
  it("shows the trace ages and the cross-source statement in SS mode", async () => {
    viewOverride = snapshot("trace_ages_elevated_ss_view");
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("How far back the traces reach")).toBeTruthy();
    expect(screen.getByText(/beside when parts of this PC were set up/)).toBeTruthy();
    expect(
      screen.getByText(
        /Windows installed or last feature-upgraded \(InstallDate\): 2025-10-21, 72 days before this scan/,
      ),
    ).toBeTruthy();
    expect(screen.getByText(/Earliest installation date Windows Setup kept \(2 kept/)).toBeTruthy();
    expect(screen.getByText(/1 other logs: 1 hold records, 0 not read/)).toBeTruthy();
    expect(
      screen.getByText(/Windows removes Prefetch files itself\. \(not documented/),
    ).toBeTruthy();
    expect(screen.getByText("a clock that was changed")).toBeTruthy();

    expect(
      screen.getByText("FiveM on this PC, beside Windows' records of programs that ran"),
    ).toBeTruthy();
    expect(
      screen.getByText(
        /no entry for FiveM\.exe, GTA5\.exe, GTA5_Enhanced\.exe, PlayGTAV\.exe or FiveM_b…_GTAProcess\.exe\. It holds 1 entries; the oldest is from 2016-01-12/,
      ),
    ).toBeTruthy();
    expect(
      screen.getByText(
        "not read — Windows refused to open this. Whether it holds an entry is not known.",
      ),
    ).toBeTruthy();
    expect(screen.getByText(/This is not evidence of anything/)).toBeTruthy();
    expect(
      screen.getByText(
        "a clock that was changed, so that times from different sources are not on the same clock",
      ),
    ).toBeTruthy();
  });

  // ADR 0062: each edition's last session beside its own folders, in both languages, from the
  // synthetic hosts' snapshots — the session line, each line form, the join line, the margin, the
  // causes in full, and "not known".
  it("shows each edition's session statement in SS mode", async () => {
    const statements = snapshot(
      "session_elevated_statements",
    ) as unknown as ReportView["cross_source"];
    viewOverride = { ...snapshot("trace_ages_elevated_ss_view"), cross_source: statements };
    render(<App />);
    await openReport("ss");
    expect(
      await screen.findByText("FiveM for GTA V Legacy: its last session, beside its own folders"),
    ).toBeTruthy();
    expect(
      screen.getByText(
        "began 2025-12-31T20:00:00Z (Prefetch, FiveM.exe); ended 2025-12-31T21:30:00Z (BAM); 2 hours before this scan",
      ),
    ).toBeTruthy();
    expect(screen.getByText("last written 36 hours before the session began")).toBeTruthy();
    expect(screen.getByText("Resource cache index (priv)")).toBeTruthy();
    expect(screen.getByText("not read: the folder could not be listed")).toBeTruthy();
    expect(
      screen.getByText(
        "last created 1 minute after the session began; the folder's latest log write was 40 minutes before the session ended",
      ),
    ).toBeTruthy();
    // The per-server cache is not compared (owner decision 12 of 2026-10-02).
    expect(screen.queryByText("(written when a server is joined)")).toBeNull();
    expect(screen.queryByText("Server cache")).toBeNull();
    expect(
      screen.getAllByText(
        "A time more than 10 minutes before the session began is shown as before it; any later time as after it.",
      ),
    ).toHaveLength(2);
    expect(
      screen.getByText(
        "FiveM ended by Task Manager, a crash or a shutdown, which may skip the write it makes when it closes",
      ),
    ).toBeTruthy();
  });

  it("says when FiveM last ran is not known, in Thai", async () => {
    const statements = snapshot(
      "session_limited_running_statements",
    ) as unknown as ReportView["cross_source"];
    viewOverride = { ...snapshot("trace_ages_elevated_ss_view"), cross_source: statements };
    await i18n.changeLanguage("th");
    render(<App />);
    await openReport("self");
    expect(
      await screen.findByText("ยังรันอยู่ตั้งแต่ 2025-12-31T23:40:00Z (process ที่กำลังรัน, FiveM.exe)"),
    ).toBeTruthy();
    expect(
      screen.getByText(/^ไม่รู้ว่า FiveM รันครั้งล่าสุดเมื่อไร เพราะอ่าน Prefetch และ BAM ไม่ได้ \(/),
    ).toBeTruthy();
  });

  it("says a source not read without administrator rights is not known, in Thai too", async () => {
    const view = snapshot("trace_ages_elevated_ss_view");
    const ages = view.trace_ages;
    if (!ages) {
      throw new Error("the snapshot has no trace ages");
    }
    viewOverride = {
      ...view,
      cross_source: [],
      trace_ages: {
        ...ages,
        rows: ages.rows.map((row) =>
          row.collector === "prefetch"
            ? { collector: "prefetch", state: "unmeasured", reason: "not_admin" }
            : row,
        ),
      },
    };
    await i18n.changeLanguage("th");
    render(<App />);
    await openReport("self");
    expect(await screen.findByText("ร่องรอยย้อนกลับไปได้ไกลแค่ไหน")).toBeTruthy();
    expect(screen.getByText("อ่านไม่ได้เพราะไม่มีสิทธิ์ผู้ดูแลระบบ — ไม่รู้")).toBeTruthy();
    expect(screen.queryByText("FiveM ในเครื่องนี้ เทียบกับบันทึกของ Windows ว่าโปรแกรมใดเคยรัน")).toBeNull();
  });

  it("shows the timeline in SS mode with its note and the scan time", async () => {
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("Timeline")).toBeTruthy();
    expect(screen.getByText(/An order of recorded times is not an order of events/)).toBeTruthy();
    expect(screen.getByText("This scan ran")).toBeTruthy();
    expect(screen.getByText(ssView.header.generated_at)).toBeTruthy();
  });

  it("names the selector behind a selected time and its ordinary causes", async () => {
    viewOverride = {
      ...ssView,
      timeline: {
        entries: [
          {
            at: "2026-09-15T18:02:11Z",
            collector: "prefetch",
            field: "last_run",
            place: null,
            source: { kind: "selector", selector_id: "selector-id" },
            subject: "FIVEM.EXE",
          },
        ],
        bands: [],
        unmeasured: [{ collector: "usn", reason: "not_admin" }],
      },
    };
    extraTexts = {
      "selector-id": {
        title: "When Prefetch recorded a program named like FiveM or GTA V",
        description: "Puts a time on the timeline.",
        falsepositives: ["Any program of one of these names"],
        retention: "Only the Prefetch files still in the folder.",
        status: "experimental",
        files: { rule: "r", fixtures: "f", collector: "c", references: [] },
      },
    };
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText(/Windows Prefetch · FIVEM\.EXE/)).toBeTruthy();
    expect(
      screen.getAllByText(/When Prefetch recorded a program named like FiveM or GTA V/).length,
    ).toBe(2);
    expect(screen.getByText("Any program of one of these names")).toBeTruthy();
    expect(
      screen.getByText(
        "NTFS change journal: not measured — Windows would not show this without administrator rights",
      ),
    ).toBeTruthy();
  });

  it("says what will be examined and starts nothing without consent", async () => {
    render(<App />);
    expect(await screen.findByText("What will be examined")).toBeTruthy();
    expect(
      screen.getByText(/Prefetch, BAM, PCA, UserAssist, MuiCache, FeatureUsage and AppCompatCache/),
    ).toBeTruthy();
    expect(screen.getByText(/never history, cookies or passwords/)).toBeTruthy();
    expect(screen.getByText("You may refuse: close the program and nothing is read.")).toBeTruthy();
    const start = screen.getByText("Start the check") as HTMLButtonElement;
    expect(start.disabled).toBe(true);
    fireEvent.click(start);
    expect(calls).not.toContain("start_scan");
    expect(calls).not.toContain("report_view");
  });

  it("shows the scan's real progress and lets it be cancelled, with no report", async () => {
    scanState = "running";
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("1 of 3 modules (33%)")).toBeTruthy();
    expect(screen.getByText("read · 4 observations")).toBeTruthy();
    fireEvent.click(screen.getByText("Cancel the check"));
    expect(await screen.findByText("Check cancelled", {}, { timeout: 3000 })).toBeTruthy();
    expect(calls).toContain("cancel_scan");
    expect(calls).not.toContain("report_view");
  });

  it("starts an advanced scan only when it was chosen", async () => {
    render(<App />);
    await openReport("ss", "full");
    await screen.findByText("Found");
    expect(startedTier).toBe("full");
  });

  it("shows the SS view with hidden counts after consent", async () => {
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("Found")).toBeTruthy();
    expect(await screen.findByText("Check: Secure Boot is turned off")).toBeTruthy();
    // One not-found rule is hidden: `tpm-absent` is `context` strength, and SS mode lists a context
    // rule only when it matches, while posture rules are listed whatever their state (ADR 0011).
    // Eighteen not-measured rules are hidden: the firmware reading needs administrator rights, which this
    // fixture's scan did not have, so it is said once in the scope line rather than as a row (ADR 0038);
    // the seven full-scan rules, because this was a standard scan, which every rule expects (ADR 0052,
    // ADR 0055, ADR 0064); the
    // seven `os_image` rules, because this fixture describes no `CurrentVersion` key for them to read
    // (ADR 0056); and three `install_marker` rules, because the fixture sets no environment variable
    // for the folders they name (ADR 0057). The one unmatched observation is `install_marker`'s
    // registry marker, which needs no environment variable and answered `present: false`. B.O.P.E 0.10.0
    // adds three full-scan rules (`mft`, `shellbags`) and the `srum` and `wmi_subscription` rules this
    // fixture's limited scan expects not to measure, and the new sources' unmatched rows (ADR 0124–0127).
    expect(
      screen.getByText(
        "Hidden in SS mode: 26 not found · 33 not measured (expected) · 0 not measured (not expected) · 29 unmatched observations",
      ),
    ).toBeTruthy();
    expect(calls).toContain("report_view");
  });

  it("shows the program version in the report header, which the release notes ask people to check", async () => {
    render(<App />);
    await openReport("self");
    expect(await screen.findByText("Version")).toBeTruthy();
    expect(screen.getByText(selfView.header.provenance.version)).toBeTruthy();
  });

  // One line of context in the header, in both modes, with the caveat beside it that stops a start
  // days before the scan being read as something the player did (ADR 0039).
  it.each([["self" as const], ["ss" as const]])(
    "shows when Windows started, with its caveat, in %s mode",
    async (mode) => {
      render(<App />);
      await openReport(mode);
      expect(await screen.findByText("Windows start")).toBeTruthy();
      expect(screen.getByText(/^2025-12-28T21:56:56Z, 3d 2h 3m before this scan\./)).toBeTruthy();
      expect(screen.getByText(/Not reset by "Shut down" with Fast Startup/)).toBeTruthy();
    },
  );

  it("shows when Windows started in Thai", async () => {
    render(<App />);
    await act(async () => {
      await i18n.changeLanguage("th");
    });
    await openReport("self");
    expect(await screen.findByText("Windows เริ่มทำงาน")).toBeTruthy();
    expect(
      screen.getByText(/^2025-12-28T21:56:56Z \(3 วัน 2 ชม\. 3 นาที ก่อนการสแกนนี้\)/),
    ).toBeTruthy();
  });

  // No time where none was measured, and the reason in the words every unmeasured row uses.
  it("shows an unmeasured boot time as a reason and no time", async () => {
    viewOverride = {
      ...selfView,
      header: { ...selfView.header, boot_time: { state: "unmeasured", reason: "not_windows" } },
      // The trace ages read the same header in Rust, so their boot-time anchor says the same.
      trace_ages: selfView.trace_ages && {
        ...selfView.trace_ages,
        anchors: selfView.trace_ages.anchors.map((anchor) =>
          anchor.anchor === "boot_time"
            ? { anchor: "boot_time", state: "unmeasured", reason: "not_windows" }
            : anchor,
        ),
      },
    };
    render(<App />);
    await openReport("self");
    expect(await screen.findByText("not measured — not running on Windows")).toBeTruthy();
    expect(screen.queryByText(/before this scan/)).toBeNull();
  });

  it("offers the administrator restart before scanning when the program has no administrator rights", async () => {
    infoElevated = false;
    render(<App />);
    expect(await screen.findByText("Restart as administrator")).toBeTruthy();
    expect(screen.getByText("standard user — some sources will not be read")).toBeTruthy();
  });

  it("does not offer the administrator restart when the program already has those rights", async () => {
    render(<App />);
    // The banner proves the facts arrived, so the button is absent by choice and not by timing.
    await screen.findByRole("alert");
    expect(screen.queryByText("Restart as administrator")).toBeNull();
  });

  it("does not offer the administrator restart before the program's facts have loaded", () => {
    infoElevated = false;
    render(<App />);
    expect(screen.queryByText("Restart as administrator")).toBeNull();
  });

  it("switches to Thai, keeping the UNOFFICIAL BUILD token in English", async () => {
    render(<App />);
    await act(async () => {
      await i18n.changeLanguage("th");
    });
    await openReport("self");
    expect(await screen.findByText("ตรวจ: Secure Boot ถูกปิดอยู่")).toBeTruthy();
    expect(screen.getByRole("alert").textContent).toContain("UNOFFICIAL BUILD");
  });

  it("lists what the tool itself left, apart from the evidence", async () => {
    viewOverride = {
      ...selfView,
      own_traces: [
        {
          collector: "process",
          observation: {
            collector: "process",
            fields: {
              name: "aeterna-rongroi.exe",
              path: "%USERPROFILE%\\Downloads\\aeterna-rongroi.exe",
            },
          },
        },
      ],
    };
    render(<App />);
    await openReport("self");
    const section = await screen.findByRole("region", { name: "Own traces (excluded)" });
    expect(section.textContent).toContain("aeterna-rongroi.exe");
    // The evidence list above it is untouched.
    expect(screen.getByText("Check: Secure Boot is turned off")).toBeTruthy();
  });

  it("lists what the collectors saw that no rule matched, apart from the evidence", async () => {
    viewOverride = {
      ...selfView,
      unmatched: [
        {
          collector: "fivem_dir",
          observations: [
            {
              collector: "fivem_dir",
              fields: {
                location: "plugins",
                path: "C:\\Users\\a\\AppData\\Local\\FiveM\\FiveM.app\\plugins\\overlay.dll",
              },
            },
          ],
        },
      ],
    };
    render(<App />);
    await openReport("self");
    const section = await screen.findByRole("region", { name: "Unmatched observations" });
    expect(section.textContent).toContain("overlay.dll");
    // The evidence list above it is untouched.
    expect(screen.getByText("Check: Secure Boot is turned off")).toBeTruthy();
  });

  it("shows no unmatched section when every observation matched a rule", async () => {
    // The view is given no unmatched group, which is the case under test. The fixture behind
    // `selfView` does produce one — `install_marker` answers its registry marker `present: false` on
    // a host that describes no environment (ADR 0057) — and that is another test's business.
    viewOverride = { ...selfView, unmatched: [] };
    render(<App />);
    await openReport("self");
    // The evidence proves the view arrived, so the section is absent by choice and not by timing.
    await screen.findByText("Check: Secure Boot is turned off");
    expect(screen.queryByRole("region", { name: "Unmatched observations" })).toBeNull();
  });

  // A match shown without what else produces it is a match shown as an accusation. Both halves are
  // written in every rule and translated, and neither reached a screen before (ADR 0027).
  it("shows a found entry's description and its false positives", async () => {
    render(<App />);
    await openReport("self");
    await screen.findByText("Check: Secure Boot is turned off");
    expect(screen.getByText(`About this check: ${ENGLISH_DESCRIPTION}`)).toBeTruthy();
    expect(screen.getByText("Ordinary things that also produce this:")).toBeTruthy();
    expect(screen.getByText(ENGLISH_FALSEPOSITIVE)).toBeTruthy();
  });

  it("shows a found entry's description and its false positives in Thai", async () => {
    render(<App />);
    await act(async () => {
      await i18n.changeLanguage("th");
    });
    await openReport("self");
    await screen.findByText("ตรวจ: Secure Boot ถูกปิดอยู่");
    expect(screen.getByText(`เกี่ยวกับการตรวจนี้: ${THAI_DESCRIPTION}`)).toBeTruthy();
    expect(screen.getByText("เรื่องปกติที่ทำให้เกิดผลแบบนี้ได้เหมือนกัน:")).toBeTruthy();
    expect(screen.getByText(THAI_FALSEPOSITIVE)).toBeTruthy();
  });

  // `description` says what the check is, which a reader needs whatever the answer was;
  // `falsepositives` explains a match, and nothing matched.
  it("shows the description but no false positives beside a not-found entry", async () => {
    const first = subject(selfView);
    viewOverride = {
      ...selfView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "not_found",
          retention: ENGLISH_RETENTION,
        },
      ],
    };
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByText("Not found: 1 — show what was checked"));
    openRow("Check: Secure Boot is turned off");
    expect(await screen.findByText(`About this check: ${ENGLISH_DESCRIPTION}`)).toBeTruthy();
    expect(screen.queryByText("Ordinary things that also produce this:")).toBeNull();
    expect(screen.queryByText(ENGLISH_FALSEPOSITIVE)).toBeNull();
  });

  // The whole of what `unmeasured_when` does to a view: a reason the rule named is a number, a
  // reason it did not name is a row (ADR 0027).
  it("lists the unmeasured result its rule did not expect and counts the one it did", async () => {
    const first = subject(selfView);
    viewOverride = {
      ...ssView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "unmeasured",
          reason: "read_failed",
          expected: false,
        },
      ],
      hidden: { ...ssView.hidden, unmeasured_expected: 3 },
    };
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("Not measured (not expected)")).toBeTruthy();
    expect(
      screen.getByText(
        "Hidden in SS mode: 26 not found · 3 not measured (expected) · 0 not measured (not expected) · 29 unmatched observations",
      ),
    ).toBeTruthy();
  });

  // One fact about the scan that applies to every rule at once, and the one unmeasured reason with
  // a remedy, so it is stated once above the evidence (ADR 0012, ADR 0027).
  it("states missing administrator rights once, above the evidence", async () => {
    viewOverride = { ...selfView, scope: { not_admin: 2, not_attempted: 0 } };
    render(<App />);
    await openReport("self");
    const statements = await screen.findAllByText(/could not be answered because this scan/);
    expect(statements).toHaveLength(1);
    expect(statements[0]?.textContent).toContain("2 check(s)");
  });

  // The second scope statement, and the same shape for the same reason: a source this program
  // stopped short of is one fact about how far the scan got, and it says so about the program and
  // never about the PC (ADR 0030).
  it("states the sources it never reached once, above the evidence", async () => {
    viewOverride = { ...selfView, scope: { not_admin: 0, not_attempted: 3 } };
    render(<App />);
    await openReport("self");
    const statements = await screen.findAllByText(/this program stopped reading before/);
    expect(statements).toHaveLength(1);
    expect(statements[0]?.textContent).toContain("3 check(s)");
    expect(statements[0]?.textContent).toContain("not a finding about this PC");
  });

  // Each of the fourteen reasons reaches a reader as a sentence, never as its identifier: a row
  // reading `source_empty` is a row that says nothing to the person it is about (ADR 0030).
  it.each([
    ["not_on_this_os", "this version of Windows does not keep this record"],
    ["not_attempted", "the scan stopped before reaching it"],
    ["service_disabled", "the Windows service that writes this record is switched off"],
    ["source_absent", "this PC has no such record to read"],
    ["source_empty", "the place this is kept is there and holds nothing"],
    ["partial", "part of this was read and part of it was not"],
    ["budget_spent", "this program stopped reading before it finished"],
    ["not_consented", "only a full scan reads this, and this was the standard scan"],
    ["other_volume", "this is on another drive, and this program reads only the system drive"],
  ])("shows %s as a sentence a non-expert reads", async (reason, sentence) => {
    const first = selfView.evidence[0];
    if (!first) {
      throw new Error("the self-view snapshot has no evidence");
    }
    viewOverride = {
      ...selfView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "unmeasured",
          reason: reason as UnmeasuredReason,
          expected: false,
        },
      ],
      // The row is what this test reads; the timeline and the trace ages state their own
      // unmeasured sources.
      timeline: { ...selfView.timeline, unmeasured: [] },
      trace_ages: undefined,
    };
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByText(/^Check: /));
    expect(await screen.findByText(new RegExp(sentence))).toBeTruthy();
  });

  // A count the change journal gives is for the span it still held; the row says that span, and a
  // source that held no record says there was none (ADR 0047, amendment of 2026-09-30).
  it.each([
    [
      { state: "span", from: "2026-09-30T10:24:00Z", to: "2026-09-30T11:03:00Z" },
      /held only 2026-09-30T10:24:00Z to 2026-09-30T11:03:00Z/,
    ],
    [{ state: "no_span" }, /so there is no span/],
  ] as const)("shows the span a row's count is for (%o)", async (band, sentence) => {
    const first = selfView.evidence[0];
    if (!first) {
      throw new Error("the self-view snapshot has no evidence");
    }
    viewOverride = {
      ...selfView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "found",
          observations: [],
        },
      ],
      row_bands: { [first.rule_id]: band },
    };
    render(<App />);
    await openReport("self");
    expect(await screen.findByText(sentence)).toBeTruthy();
  });

  // The third scope statement: which scan the player chose is one fact about the scan (ADR 0052).
  it("states the checks only a full scan answers once, above the evidence", async () => {
    viewOverride = { ...selfView, scope: { not_admin: 0, not_attempted: 0, not_consented: 1 } };
    render(<App />);
    await openReport("self");
    const statements = await screen.findAllByText(/read only in a full scan/);
    expect(statements).toHaveLength(1);
    expect(statements[0]?.textContent).toContain("1 check(s)");
  });

  // A full scan is chosen in a new copy that asks in a Windows dialog before it reads anything; this
  // window only offers it, and says so (ADR 0052).
  it("offers the website-name choice only for an advanced SS check, and passes the answer to the view", async () => {
    const seen: unknown[] = [];
    render(<App />);
    fireEvent.click(await screen.findByLabelText(/Screenshare \(SS mode\)/));
    expect(screen.queryByRole("checkbox", { name: /website names/ })).toBeNull();
    fireEvent.click(screen.getByLabelText(/^Advanced/));
    const toggle = screen.getByRole("checkbox", { name: /website names/ }) as HTMLInputElement;
    // Off until the player turns it on.
    expect(toggle.checked).toBe(false);
    fireEvent.click(toggle);
    fireEvent.click(screen.getByLabelText("I have read what will be examined and I agree"));
    const answer = mockIPCAnswer;
    mockIPC((cmd, args) => {
      if (cmd === "report_view") {
        seen.push((args as Record<string, unknown>).options);
      }
      return answer(cmd, args);
    });
    fireEvent.click(screen.getByText("Start the check"));
    await screen.findByText("Found");
    expect(seen).toContainEqual({
      server_identity: false,
      account_identifier: false,
      download_host: true,
    });
  });

  it("saves the report where the person chose, and shows each file's SHA-256", async () => {
    render(<App />);
    await openReport("ss");
    await screen.findByText("Found");
    fireEvent.click(await screen.findByText("Save report"));
    expect(await screen.findByText("ab".repeat(32))).toBeTruthy();
    expect(exportedWith?.mode).toBe("ss");
    expect(exportedWith?.formats).toEqual(["html", "json", "txt", "pdf"]);
    expect(screen.getByText(/does not prove the scan was honest/)).toBeTruthy();
  });

  it("states nothing about administrator rights when every check was answerable", async () => {
    // The snapshot's own scan could not read the firmware without those rights (ADR 0038), so the
    // answerable case is written here: the same view with no rule stopped by them.
    viewOverride = { ...selfView, scope: { not_admin: 0, not_attempted: 0 } };
    render(<App />);
    await openReport("self");
    // The evidence proves the view arrived, so the statement is absent by choice and not by timing.
    await screen.findByText("Check: Secure Boot is turned off");
    expect(screen.queryByText(/could not be answered because this scan/)).toBeNull();
  });

  it("shows the look-back note of not-found evidence in the chosen language", async () => {
    const first = subject(selfView);
    viewOverride = {
      ...selfView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "not_found",
          retention: ENGLISH_RETENTION,
        },
      ],
    };
    render(<App />);
    await act(async () => {
      await i18n.changeLanguage("th");
    });
    await openReport("self");
    fireEvent.click(await screen.findByText("ไม่เจอ 1 รายการ — กดเพื่อดูว่าตรวจอะไรไปบ้าง"));
    fireEvent.click(screen.getByText("ตรวจ: Secure Boot ถูกปิดอยู่"));
    expect(await screen.findByText(`ย้อนดูได้: ${THAI_RETENTION}`)).toBeTruthy();
    expect(screen.queryByText(ENGLISH_RETENTION, { exact: false })).toBeNull();
  });

  // Three counts of states and the sentence that no report proves a PC clean, above the rows; never
  // one number (ADR 0002, ADR 0045).
  it("lists how many rows are in each state, beside the sentence that it proves nothing clean", async () => {
    render(<App />);
    await openReport("self");
    const summary = await screen.findByRole("region", { name: "What this scan lists" });
    const buttons = Array.from(summary.querySelectorAll("button"));
    expect(buttons.map((b) => b.textContent)).toEqual([
      `${selfView.listed.found} found — each one lists ordinary things that also produce it`,
      `${selfView.listed.not_found} not found — each row says how far back it can see`,
      `${selfView.listed.unmeasured} not measured — each row says why`,
    ]);
    // A screen reader reads the count and its words apart, not "1found".
    expect(
      screen.getByRole("button", {
        name: `${selfView.listed.found} found — each one lists ordinary things that also produce it`,
      }),
    ).toBeTruthy();
    expect(summary.textContent).toContain("This report cannot prove that a PC is clean");
  });

  it("filters the rows to one state from its count", async () => {
    render(<App />);
    await openReport("self");
    const summary = await screen.findByRole("region", { name: "What this scan lists" });
    const found = summary.querySelector("button");
    if (!found) throw new Error("no count");
    fireEvent.click(found);
    expect(found.getAttribute("aria-pressed")).toBe("true");
    expect(screen.getByText("Check: Secure Boot is turned off")).toBeTruthy();
    expect(screen.queryByText(/— show what was checked$/)).toBeNull();
    fireEvent.click(screen.getByText("Show every state"));
    expect(found.getAttribute("aria-pressed")).toBe("false");
  });

  // A count of 0 is a button like the others; choosing it must not leave an empty page.
  it("says so when the chosen state has no row", async () => {
    viewOverride = {
      ...selfView,
      evidence: selfView.evidence.filter((item) => item.state !== "unmeasured"),
      listed: { ...selfView.listed, unmeasured: 0 },
    };
    render(<App />);
    await openReport("self");
    const summary = await screen.findByRole("region", { name: "What this scan lists" });
    expect(screen.queryByText("No row in this scan is in this state.")).toBeNull();
    fireEvent.click(summary.querySelectorAll("button")[2] as HTMLElement);
    expect(screen.getByText("No row in this scan is in this state.")).toBeTruthy();
    // It is about the filter, not the report: the report's own empty sentence stays away.
    expect(screen.queryByText("No evidence to show.")).toBeNull();
    fireEvent.click(screen.getByText("Show every state"));
    expect(screen.queryByText("No row in this scan is in this state.")).toBeNull();
  });

  // Two copies of one program running are two identical observations (ADR 0010).
  it("lists two identical observations twice, without a repeated key", async () => {
    const twin = {
      collector: "process",
      fields: { name: "FiveM.exe", path: "C:\\Users\\a\\AppData\\Local\\FiveM\\FiveM.exe" },
    };
    viewOverride = {
      ...selfView,
      unmatched: [{ collector: "process", observations: [twin, twin] }],
    };
    const errors = vi.spyOn(console, "error").mockImplementation(() => {});
    try {
      render(<App />);
      await openReport("self");
      const section = await screen.findByRole("region", { name: "Unmatched observations" });
      expect(section.querySelectorAll("li").length).toBeGreaterThanOrEqual(2);
      expect(section.textContent?.split("name=FiveM.exe").length).toBe(3);
      const keyWarnings = errors.mock.calls.filter((call) =>
        call.some((part) => String(part).includes("same key")),
      );
      expect(keyWarnings).toEqual([]);
    } finally {
      errors.mockRestore();
    }
  });

  it("groups rows under a plain name for their collector", async () => {
    render(<App />);
    await act(async () => {
      await i18n.changeLanguage("th");
    });
    await openReport("self");
    expect(await screen.findByRole("region", { name: "การตั้งค่าความปลอดภัยของเครื่อง" })).toBeTruthy();
  });

  it("starts a not-found row closed, with the description cut short and not labelled", async () => {
    const first = subject(selfView);
    viewOverride = {
      ...selfView,
      evidence: [
        {
          rule_id: first.rule_id,
          collector: first.collector,
          strength: first.strength,
          state: "not_found",
          retention: ENGLISH_RETENTION,
        },
      ],
    };
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByText("Not found: 1 — show what was checked"));
    const head = screen.getByText("Check: Secure Boot is turned off").closest("button");
    expect(head?.getAttribute("aria-expanded")).toBe("false");
    expect(screen.getByText(ENGLISH_DESCRIPTION)).toBeTruthy();
    expect(screen.queryByText(`About this check: ${ENGLISH_DESCRIPTION}`)).toBeNull();
  });

  it("opens technical details and the rule's files at this build's commit", async () => {
    linksOverride = {
      repository: REPOSITORY,
      code: `${REPOSITORY}/tree/${COMMIT}`,
      commit: COMMIT,
    };
    stubClipboard("ok");
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByLabelText("Show technical details for every row"));
    expect(screen.getAllByText(RULE_ID).length).toBeGreaterThan(0);
    expect(screen.getAllByText("secure_boot").length).toBeGreaterThan(0);
    const rulePath = screen.getByText("rules/posture/boot/secure-boot-disabled/rule.yaml");
    const copy = rulePath.parentElement?.querySelector("button");
    if (!copy) throw new Error("no copy button");
    await act(async () => {
      fireEvent.click(copy);
    });
    expect(clipboardWrites).toEqual([
      `${REPOSITORY}/blob/${COMMIT}/rules/posture/boot/secure-boot-disabled/rule.yaml`,
    ]);
    expect(copy.textContent).toBe("Copied");
  });

  it("shows no file links for an unofficial build and says why", async () => {
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByLabelText("Show technical details for every row"));
    const rulePath = await screen.findByText("rules/posture/boot/secure-boot-disabled/rule.yaml");
    expect(rulePath.parentElement?.querySelector("button")).toBeNull();
    expect(screen.getAllByText(/This build is not official/).length).toBeGreaterThan(0);
  });

  // An official build whose commit was not recorded is still official: the sentence says the commit
  // is not known, never that the build is not official.
  it("says the commit is not known, not that the build is unofficial, for an official build without one", async () => {
    const official = {
      ...selfView.header,
      provenance: { ...selfView.header.provenance, official: true, commit: null },
    };
    headerOverride = official;
    viewOverride = { ...selfView, header: official };
    linksOverride = { repository: REPOSITORY, code: REPOSITORY, commit: null };
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByLabelText("Show technical details for every row"));
    const rulePath = await screen.findByText("rules/posture/boot/secure-boot-disabled/rule.yaml");
    expect(rulePath.parentElement?.querySelector("button")).toBeNull();
    expect(
      (await screen.findAllByText(/The commit this program was built from is not known\./)).length,
    ).toBeGreaterThan(0);
    expect(screen.queryByText(/This build is not official/)).toBeNull();
  });

  // Carried fix (b): before `codeLinks()` has arrived (or after it has failed), the report does not
  // yet know whether this build is official, so it must not say either thing about the commit.
  it("says nothing about the build's commit before the code links resolve", async () => {
    linksNeverResolve = true;
    render(<App />);
    await openReport("self");
    fireEvent.click(await screen.findByLabelText("Show technical details for every row"));
    const rulePath = await screen.findByText("rules/posture/boot/secure-boot-disabled/rule.yaml");
    expect(rulePath.parentElement?.querySelector("button")).toBeNull();
    expect(screen.queryByText(/This build is not official/)).toBeNull();
    expect(screen.queryByText(/At the commit this program was built from/)).toBeNull();
  });

  it("opens About & code from the start screen, with the repository and its QR code", async () => {
    stubClipboard("ok");
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    expect(await screen.findByText("About this program and its code")).toBeTruthy();
    expect(screen.getByText(REPOSITORY)).toBeTruthy();
    const qr = await screen.findByAltText(`QR code for ${REPOSITORY}`);
    expect(qr.getAttribute("src")).toMatch(/^data:image\/svg\+xml;charset=utf-8,/);
    // The snapshot's build is unofficial: its code is not known, and the page says so.
    expect(screen.getByText(/The code this build was made from is not known/)).toBeTruthy();
    // The window uses the consent screen's form of the ADR 0003 statement (`consent.sends`,
    // `consent.webview`), which ADR 0045 §7 keeps unchanged.
    expect(screen.getByText("aeterna-rongroi's own code sends nothing anywhere.")).toBeTruthy();
    await act(async () => {
      fireEvent.click(screen.getAllByText("Copy link")[0] as HTMLElement);
    });
    expect(clipboardWrites).toEqual([REPOSITORY]);
  });

  it("links the commit of an official build and the attestation command for its file", async () => {
    headerOverride = {
      ...selfView.header,
      provenance: { ...selfView.header.provenance, official: true, commit: COMMIT },
    };
    linksOverride = {
      repository: REPOSITORY,
      code: `${REPOSITORY}/tree/${COMMIT}`,
      commit: COMMIT,
    };
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    expect(await screen.findByText(`${REPOSITORY}/tree/${COMMIT}`)).toBeTruthy();
    expect(
      screen.getByText(
        `gh attestation verify aeterna-rongroi-${selfView.header.provenance.version}-windows-x64.exe -R aeterna/aeterna-rongroi`,
      ),
    ).toBeTruthy();
    expect(screen.queryByText(/The code this build was made from is not known/)).toBeNull();
  });

  it("says on About & code that an official build's commit is not known, without calling it unofficial", async () => {
    headerOverride = {
      ...selfView.header,
      provenance: { ...selfView.header.provenance, official: true, commit: null },
    };
    linksOverride = { repository: REPOSITORY, code: REPOSITORY, commit: null };
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    expect(
      await screen.findByText("The commit this build was made from is not known."),
    ).toBeTruthy();
    expect(screen.queryByText(/not built by the release workflow/)).toBeNull();
  });

  // About & code is reachable from every screen, so leaving it returns to the screen it was opened
  // from: an SS report stays an SS report, without asking for consent a second time.
  it("returns from About & code to the report it was opened from", async () => {
    render(<App />);
    await openReport("ss");
    expect(await screen.findByText("Found")).toBeTruthy();
    fireEvent.click(screen.getByText("About & code"));
    expect(await screen.findByText("About this program and its code")).toBeTruthy();
    // Opening it again from itself must not make it its own way back.
    fireEvent.click(screen.getByText("About & code"));
    fireEvent.click(screen.getAllByText("Back")[0] as HTMLElement);
    expect(await screen.findByText("Found")).toBeTruthy();
    expect(screen.getByText(/^Hidden in SS mode:/)).toBeTruthy();
    expect(screen.queryByText("You may refuse.")).toBeNull();
    expect(screen.queryByText("What do you want to do?")).toBeNull();
  });

  // The header is the app's: About & code does not ask Rust for it a second time.
  it("asks for the header once, whether or not About & code is opened", async () => {
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    await screen.findByText(REPOSITORY);
    expect(calls.filter((cmd) => cmd === "app_info")).toEqual(["app_info"]);
  });

  it("says on About & code that its details could not be read, and still goes back", async () => {
    linksFail = true;
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    expect(
      await screen.findByText("What this page shows could not be read from the program."),
    ).toBeTruthy();
    fireEvent.click(screen.getAllByText("Back")[0] as HTMLElement);
    expect(await screen.findByText("What will be examined")).toBeTruthy();
  });

  it("says on About & code that its details could not be read when the header was refused", async () => {
    headerFails = true;
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    expect(
      await screen.findByText("What this page shows could not be read from the program."),
    ).toBeTruthy();
  });

  it("offers to copy again after saying Copied", async () => {
    stubClipboard("ok");
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    await screen.findByText(REPOSITORY);
    vi.useFakeTimers();
    try {
      await act(async () => {
        fireEvent.click(screen.getAllByText("Copy link")[0] as HTMLElement);
      });
      expect(screen.getByText("Copied")).toBeTruthy();
      act(() => {
        vi.advanceTimersByTime(COPIED_FOR_MS - 1);
      });
      expect(screen.getByText("Copied")).toBeTruthy();
      act(() => {
        vi.advanceTimersByTime(1);
      });
      expect(screen.queryByText("Copied")).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });

  it("says a refused copy and leaves the text to select", async () => {
    stubClipboard("refused");
    render(<App />);
    fireEvent.click(await screen.findByText("About & code"));
    await screen.findByText(REPOSITORY);
    await act(async () => {
      fireEvent.click(screen.getAllByText("Copy link")[0] as HTMLElement);
    });
    expect(screen.getByText("Could not copy — select the text instead")).toBeTruthy();
  });
});
