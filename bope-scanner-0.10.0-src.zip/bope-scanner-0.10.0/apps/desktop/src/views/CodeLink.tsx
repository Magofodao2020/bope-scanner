// SPDX-FileCopyrightText: 2026 aeterna-rongroi contributors
// SPDX-License-Identifier: GPL-3.0-or-later
// Part of aeterna-rongroi, a cheat-detection tool. Using it to evade detection is out of scope — see AGENTS.md.

import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { codeLinkQr } from "../api";

/** How long the button says "Copied" before it offers to copy again. */
export const COPIED_FOR_MS = 2000;

interface Props {
  /** What is shown, selectable. */
  text: string;
  /** What the Copy button copies and the QR code encodes; no button when `null`. */
  copy: string | null;
  qr?: boolean;
}

/**
 * A link the window cannot open: selectable text, a Copy button and, where asked, a QR code drawn in
 * Rust. There is no network code and no plugin to open a browser with (ADR 0003, ADR 0045).
 */
export function CodeLink({ text, copy, qr = false }: Props) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState<"idle" | "copied" | "failed">("idle");
  const [image, setImage] = useState<string | null>(null);

  // "Copied" answers one click; left on the button it would still claim so after the clipboard has
  // changed. A refusal stays, because it says what to do instead.
  useEffect(() => {
    if (copied !== "copied") {
      return;
    }
    const timer = setTimeout(() => setCopied("idle"), COPIED_FOR_MS);
    return () => clearTimeout(timer);
  }, [copied]);

  useEffect(() => {
    setImage(null);
    if (!qr || !copy) {
      return;
    }
    // Carried fix (a): a response for a URL this effect has since moved on from (because `copy`
    // changed, or the component unmounted) must not set the image for the new URL.
    let cancelled = false;
    void codeLinkQr(copy)
      .then((svg) => {
        if (cancelled) {
          return;
        }
        setImage(svg ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}` : null);
      })
      // A refused call leaves no image, and the text and Copy button beside it still work.
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [qr, copy]);

  async function onCopy(value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied("copied");
    } catch {
      // Refused or unavailable: the text beside the button stays selectable.
      setCopied("failed");
    }
  }

  return (
    <span className="code-link">
      <code className="selectable">{text}</code>
      {copy && (
        <button type="button" className="copy" onClick={() => void onCopy(copy)}>
          {t(`code.copy_${copied}`)}
        </button>
      )}
      {image && copy && (
        <img
          className="qr"
          src={image}
          alt={t("code.qr_alt", { url: copy })}
          width={160}
          height={160}
        />
      )}
    </span>
  );
}
